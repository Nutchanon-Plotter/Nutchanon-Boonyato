@extends('real_components/navbar')

@section('title')
    Home
@endsection

@section('content')
    <div class="land1">
        <div class="grid grid-rows-2 gap-4">
            <div class="paddingland1">
                <a href="/login">
                    <div>
                        <img src="{{url('images/btnland.svg')}}" class="btn-land" alt="">
                    </div>
                </a>
            </div>
        </div>
    </div>
    <div class="land2">
    </div>
    <div class="land3">
    </div>
    <div class="land4">
    </div>
@endsection